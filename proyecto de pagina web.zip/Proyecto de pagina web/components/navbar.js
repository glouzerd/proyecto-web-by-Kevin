class CustomNavbar extends HTMLElement {
    connectedCallback() {
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                :host {
                    display: block;
                    width: 100%;
                    background-color: #1a365d;
                    color: white;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                }
                
                .navbar-container {
                    display: flex;
                    flex-direction: column;
                    max-width: 1440px;
                    margin: 0 auto;
                    padding: 0.5rem 1rem;
                }
                
                .top-bar {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 0.5rem 0;
                }
                
                .logo-container {
                    display: flex;
                    align-items: center;
                }
                
                /* EDITABLE: Replace with your logo */
                .logo {
                    height: 40px;
                    margin-right: 1rem;
                }
                
                .search-container {
                    flex-grow: 1;
                    max-width: 600px;
                    margin: 0 2rem;
                }
                
                .search-bar {
                    width: 100%;
                    padding: 0.5rem 1rem;
                    border-radius: 4px;
                    border: none;
                    outline: none;
                }
                
                .user-actions {
                    display: flex;
                    gap: 1rem;
                }
                
                .nav-button {
                    background: none;
                    border: none;
                    color: white;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    gap: 0.25rem;
                    font-size: 0.9rem;
                    padding: 0.5rem;
                    border-radius: 4px;
                }
                
                .nav-button:hover {
                    background-color: rgba(255,255,255,0.1);
                }
                
                .bottom-bar {
                    display: flex;
                    justify-content: center;
                    padding: 0.5rem 0;
                    border-top: 1px solid rgba(255,255,255,0.1);
                }
                
                .nav-menu {
                    display: flex;
                    gap: 1rem;
                }
                
                @media (max-width: 768px) {
                    .top-bar {
                        flex-wrap: wrap;
                    }
                    
                    .search-container {
                        order: 3;
                        margin: 1rem 0;
                        min-width: 100%;
                    }
                    
                    .user-actions {
                        margin-left: auto;
                    }
                }
            </style>
            
            <div class="navbar-container">
                <div class="top-bar">
                    <div class="logo-container">
                        <!-- EDITABLE: Replace with your logo image -->
                        <img src="C:\Users\kirad\Desktop\Proyecto de pagina web\image\logo1.png" alt="ElectroFix Logo" class="logo">
                        <h1 class="text-xl font-bold">ElectroFix</h1>
</div>
                    
                    <div class="search-container">
                        <input type="text" placeholder="Buscar componentes, herramientas..." class="search-bar">
</div>
                    
                    <div class="user-actions">
                        <button class="nav-button">
                            <i data-feather="user"></i>
                            <span>Cuenta</span>
                        </button>
                        <button class="nav-button">
                            <i data-feather="shopping-cart"></i>
                            <span>Carrito</span>
                        </button>
                    </div>
                </div>
                
                <div class="bottom-bar">
                    <nav class="nav-menu">
                        <a href="#" class="nav-button">
                            <i data-feather="log-in"></i>
                            <span>Iniciar Sesión</span>
                        </a>
                        <a href="#" class="nav-button">
                            <i data-feather="user-plus"></i>
                            <span>Crear Cuenta</span>
                        </a>
                        <a href="#" class="nav-button">
                            <i data-feather="settings"></i>
                            <span>Tutoriales</span>
                        </a>
                        <a href="#" class="nav-button">
                            <i data-feather="book"></i>
                            <span>Guías Técnicas</span>
                        </a>
                        <a href="#" class="nav-button">
                            <i data-feather="tool"></i>
                            <span>Reparaciones</span>
</a>
                    </nav>
                </div>
            </div>
        `;
    }
}

customElements.define('custom-navbar', CustomNavbar);
class CustomFooter extends HTMLElement {
  connectedCallback() {
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
          background-color: #1a365d;
          color: white;
          padding: 2rem 0;
          margin-top: 3rem;
        }
        
        .footer-container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 1rem;
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 2rem;
        }
        
        .footer-section h3 {
          font-size: 1.2rem;
          margin-bottom: 1rem;
          border-bottom: 1px solid rgba(255,255,255,0.1);
          padding-bottom: 0.5rem;
        }
        
        .footer-section ul {
          list-style: none;
          padding: 0;
          margin: 0;
        }
        
        .footer-section li {
          margin-bottom: 0.5rem;
        }
        
        .footer-section a {
          color: #a0aec0;
          text-decoration: none;
          transition: color 0.2s;
        }
        
        .footer-section a:hover {
          color: white;
        }
        
        .copyright {
          text-align: center;
          margin-top: 2rem;
          padding-top: 1rem;
          border-top: 1px solid rgba(255,255,255,0.1);
          color: #a0aec0;
          font-size: 0.9rem;
        }
      </style>
      
      <div class="footer-container">
        <div class="footer-section">
          <h3>Productos</h3>
          <ul>
            <li><a href="#">PCB's</a></li>
            <li><a href="#">Herramientas</a></li>
            <li><a href="#">Componentes</a></li>
            <li><a href="#">Kits de Reparación</a></li>
          </ul>
        </div>
        
        <div class="footer-section">
          <h3>Empresa</h3>
          <ul>
            <li><a href="#">Sobre Nosotros</a></li>
            <li><a href="#">Blog Técnico</a></li>
            <li><a href="#">Tutoriales</a></li>
            <li><a href="#">Trabaja con Nosotros</a></li>
          </ul>
        </div>
        
        <div class="footer-section">
          <h3>Soporte</h3>
          <ul>
            <li><a href="#">Centro de Ayuda</a></li>
            <li><a href="#">Garantías</a></li>
            <li><a href="#">Envíos y Devoluciones</a></li>
            <li><a href="#">Contacto</a></li>
          </ul>
        </div>
        
        <div class="footer-section">
          <h3>Legal</h3>
          <ul>
            <li><a href="#">Términos y Condiciones</a></li>
            <li><a href="#">Política de Privacidad</a></li>
            <li><a href="#">Política de Cookies</a></li>
          </ul>
        </div>
      </div>
      
      <div class="copyright">
        © ${new Date().getFullYear()} ElectroFix - Todos los derechos reservados
      </div>
    `;
  }
}

customElements.define('custom-footer', CustomFooter);
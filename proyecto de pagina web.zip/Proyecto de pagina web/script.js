// Main JavaScript file for functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather Icons
    feather.replace();
    
    // Sample functionality for demo purposes
    const productCards = document.querySelectorAll('.bg-white.rounded-lg');
    
    productCards.forEach(card => {
        card.addEventListener('click', function(e) {
            if (e.target.tagName === 'BUTTON') {
                e.stopPropagation();
                // Add to cart functionality would go here
                alert('Producto añadido al carrito');
            } else {
                // Navigate to product detail page
                window.location.href = '#';
            }
        });
    });
    
    // Search functionality
    const searchInput = document.querySelector('.search-bar');
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                // Perform search
                alert(`Buscando: ${this.value}`);
            }
        });
    }
});